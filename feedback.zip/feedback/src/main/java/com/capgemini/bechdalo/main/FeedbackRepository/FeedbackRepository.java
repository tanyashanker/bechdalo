package com.capgemini.bechdalo.main.FeedbackRepository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.capgemini.bechdalo.main.feedback.Feedback;

public interface FeedbackRepository extends MongoRepository<Feedback,String> {
	//public Feedback save(Feedback feedback);
}
