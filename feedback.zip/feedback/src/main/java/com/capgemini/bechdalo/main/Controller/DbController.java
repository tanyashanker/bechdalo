package com.capgemini.bechdalo.main.Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;
import javax.validation.Valid;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import com.capgemini.bechdalo.main.feedback.Feedback;

import com.capgemini.bechdalo.main.Service.UserService;
import com.capgemini.bechdalo.main.contactus.Contact;
@RestController
public class DbController {

	
	@Autowired
	private UserService service;
	
	

	
		@RequestMapping(value="/submitFeedback", method = RequestMethod.POST)
		public Feedback submitFeedback(@Valid @RequestBody Feedback feedback) {
				return service.submitFeedback(feedback);
		}
		
		@RequestMapping(value="/submitContact", method = RequestMethod.POST)
		public Contact submitContact(@Valid @RequestBody Contact contact) {
				return service.submitContact(contact);
				
			
		}
		
	
}
