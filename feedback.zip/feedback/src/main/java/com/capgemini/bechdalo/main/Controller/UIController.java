package com.capgemini.bechdalo.main.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class UIController {

	
	@RequestMapping("/contact")
	public ModelAndView contact() {
		ModelAndView mav= new ModelAndView("contact");
		return mav;
	}
	@RequestMapping("/feedback")
	public ModelAndView feedback() {
		ModelAndView mav= new ModelAndView("feedback");
		return mav;
	}
	
}
