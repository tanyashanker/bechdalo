package com.capgemini.bechdalo.main.ContactUsRepository;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

import com.capgemini.bechdalo.main.contactus.Contact;


public interface ContactRepository extends MongoRepository<Contact,String> {
	public Contact save(Contact contact);
	
	
	
}
