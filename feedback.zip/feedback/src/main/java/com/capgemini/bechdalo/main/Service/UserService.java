package com.capgemini.bechdalo.main.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bechdalo.main.ContactUsRepository.ContactRepository;
import com.capgemini.bechdalo.main.FeedbackRepository.FeedbackRepository;
import com.capgemini.bechdalo.main.contactus.Contact;
import com.capgemini.bechdalo.main.feedback.Feedback;

@Service
public class UserService {

	
	@Autowired
	private FeedbackRepository feedrepo;
	@Autowired
	private ContactRepository contactrepo;
	
	
	
	public Feedback submitFeedback(Feedback feedback)
	{
		return feedrepo.save(feedback);
	}
	
	public Contact submitContact(Contact contact)
	{
		return contactrepo.save(contact);
	}
	
	
	
//	
//	public User findByPhone(String phone) {
//		return repo.findByPhone(phone);
//	}
//	
//	public User findByNameAndPassword(String name, String password) {
//		return repo.findByNameAndPassword(name,password);
//	}
}


