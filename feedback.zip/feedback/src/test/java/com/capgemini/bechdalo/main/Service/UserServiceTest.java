package com.capgemini.bechdalo.main.Service;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bechdalo.main.ContactUsRepository.ContactRepository;
import com.capgemini.bechdalo.main.FeedbackRepository.FeedbackRepository;
import com.capgemini.bechdalo.main.contactus.Contact;
import com.capgemini.bechdalo.main.feedback.Feedback;
import org.mockito.junit.MockitoJUnitRunner;



@RunWith(MockitoJUnitRunner.class)
public class UserServiceTest {

	
	@Mock
	private FeedbackRepository feedrepo;
	@Mock
	private ContactRepository contactrepo;
	@InjectMocks
	UserService userservice;
	
	
	@Test
	
	public void submitContactTest_1()
	{
		Contact contact=new Contact("vishnu","vishnu@gmail.com","989789","kuchbhi");
		Mockito.when(contactrepo.save(contact)).thenReturn(contact);
		Contact contact1=userservice.submitContact(contact);
		Assert.assertNotNull(contact1);
	}
	
	@Test

	public void submitContactTest_2()
	{
		
		Contact contact1=userservice.submitContact(null);
		Assert.assertNull(contact1);
	}
	
	@Test
	public void submitFeedbackTest_1()
	{
		Feedback feedback=new Feedback("vishnu","ishpujani","vishnu@gmail.com","989789","kuchbhi");
		Mockito.when(feedrepo.save(feedback)).thenReturn(feedback);
		Feedback feedback1=userservice.submitFeedback(feedback);
		Assert.assertNotNull(feedback1);
	}
	@Test
	public void submitFeedbackTest_2()
	{
		
		Feedback feedback1=userservice.submitFeedback(null);
		Assert.assertNull(null);
	}
	
//	
//	public User findByPhone(String phone) {
//		return repo.findByPhone(phone);
//	}
//	
//	public User findByNameAndPassword(String name, String password) {
//		return repo.findByNameAndPassword(name,password);
//	}
}


