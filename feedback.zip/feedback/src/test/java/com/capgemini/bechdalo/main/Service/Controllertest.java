package com.capgemini.bechdalo.main.Service;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.capgemini.bechdalo.main.Controller.DbController;
import com.capgemini.bechdalo.main.contactus.Contact;
import com.capgemini.bechdalo.main.feedback.Feedback;
@RunWith(MockitoJUnitRunner.class)
public class Controllertest {
	@Mock
	UserService service;
	@InjectMocks
	
	DbController dbController;
	@Test
	public void submitContactTest_1()
	{

		Contact contact=new Contact("vishnu","vishnu@gmail.com","989789","kuchbhi");
		Mockito.when(service.submitContact(contact)).thenReturn(contact);
		Contact contact1=dbController.submitContact(contact);
		Assert.assertNotNull(contact1);
	}
	@Test
	public void submitContactTest_2()
	{

		
		Contact contact1=dbController.submitContact(null);
		Assert.assertNull(contact1);
	}
	@Test
	public void submitFeedbackTest_1()
	{
		Feedback feedback=new Feedback("vishnu","ishpujani","vishnu@gmail.com","989789","kuchbhi");
		Mockito.when(service.submitFeedback(feedback)).thenReturn(feedback);
		Feedback feedback1=dbController.submitFeedback(feedback);
		Assert.assertNotNull(feedback1);
	}
	@Test
	public void submitFeedbackTest_2()
	{
		
		Feedback feedback1=dbController.submitFeedback(null);
		Assert.assertNull(null);
	}
	
	

}
