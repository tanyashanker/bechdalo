package com.capgemini.bechdalo.main.Service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bechdalo.main.Repository.ProductRepository;
import com.capgemini.bechdalo.main.pojo.Product;

@Service
public class ProductService {

	@Autowired
	private ProductRepository productRepository;


	public Product submitProduct(Product product) {
		
		return productRepository.save(product);
	}
	
}
