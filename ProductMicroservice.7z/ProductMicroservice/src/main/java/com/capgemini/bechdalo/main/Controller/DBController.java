package com.capgemini.bechdalo.main.Controller;

import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.bechdalo.main.Service.ProductService;
import com.capgemini.bechdalo.main.pojo.Product;

@RestController
public class DBController {

	@Autowired
	private ProductService productService;
	
	
	@PostMapping(value = "/submitProd")
	public Product createEmployee(@RequestBody Product product)
	{
	    System.out.println(product);
	    return productService.submitProduct(product);
	    
	}
	
	
	
	/*@PostMapping("/submitProd")
	public Product submitProduct(@Valid @RequestBody Product product)
	{
		return productService.submitProduct(product);
	}*/
}
