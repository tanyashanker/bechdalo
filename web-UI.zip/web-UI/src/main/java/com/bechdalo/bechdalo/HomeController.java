package com.bechdalo.bechdalo;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class HomeController {
    
	@RequestMapping("/home")
	public ModelAndView home() {
		ModelAndView mav= new ModelAndView("home");
		return mav;
	}
	@RequestMapping("/login")
	public ModelAndView login() {
		ModelAndView mav= new ModelAndView("login");
		return mav;
	}
	@RequestMapping("/register")
	public ModelAndView register() {
		ModelAndView mav= new ModelAndView("register");
		return mav;
	}
	@RequestMapping("/faq")
	public ModelAndView faq() {
		ModelAndView mav= new ModelAndView("faq");
		return mav;
	}
	@RequestMapping("/category")
	public ModelAndView category() {
		ModelAndView mav= new ModelAndView("category");
		return mav;
	}
	@RequestMapping("/contact")
	public ModelAndView contact() {
		ModelAndView mav= new ModelAndView("contact");
		return mav;
	}
	@RequestMapping("/feedback")
	public ModelAndView feedback() {
		ModelAndView mav= new ModelAndView("feedback");
		return mav;
	}
	@RequestMapping("/privacy")
	public ModelAndView privacy() {
		ModelAndView mav= new ModelAndView("PrivacyPolicy");
		return mav;
	}@RequestMapping("/terms")
	public ModelAndView terms() {
		ModelAndView mav= new ModelAndView("termsOfUse");
		return mav;
	}@RequestMapping("/postad")
	public ModelAndView postad() {
		ModelAndView mav= new ModelAndView("post-ad");
		return mav;
	}@RequestMapping("/electronics-appliances")
	public ModelAndView electronicsappliances() {
		ModelAndView mav= new ModelAndView("electronics-appliances");
		return mav;
	}@RequestMapping("/userprofile")
	public ModelAndView userprofile() {
		ModelAndView mav= new ModelAndView("userprofile");
		return mav;
	}@RequestMapping("/forgetPass")
	public ModelAndView forgetPass() {
		ModelAndView mav= new ModelAndView("forgetPassword");
		return mav;
	}@RequestMapping("/email")
	public ModelAndView email() {
		ModelAndView mav= new ModelAndView("email");
		return mav;
	}@RequestMapping("/verifyEmail")
	public ModelAndView verifyEmail() {
		ModelAndView mav= new ModelAndView("verifyEmail");
		return mav;
	}
	
	
}
