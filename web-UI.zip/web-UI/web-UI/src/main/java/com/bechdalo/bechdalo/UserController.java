package com.bechdalo.bechdalo;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.bechdalo.pojo.User;

@RestController
public class UserController {

	@Autowired
    private DiscoveryClient discoveryClient;

	@RequestMapping(value = "/submitreg", method = RequestMethod.POST)
    public ModelAndView Register(Model model, @Valid @ModelAttribute("user") User user)
    {
		System.out.println("hello");
           RestTemplate restTemplate = new RestTemplate();
           
           
           List<ServiceInstance> instances=discoveryClient.getInstances("UserService");
           ServiceInstance serviceInstance=(ServiceInstance) instances.get(0);
           String baseUrl=serviceInstance.getUri().toString();
           System.out.println(baseUrl);
                       
                  final String mail =baseUrl+"/email/"+user.getEmail();
                  final String ph = baseUrl+"phone/"+user.getPhone();
                  final String un = baseUrl+"/username/"+user.getUsername();
                  User res1 = restTemplate.getForObject(mail,User.class);
                  User res2 = restTemplate.getForObject(ph,User.class);
                  User res3 = restTemplate.getForObject(un,User.class);
                  if(res1!=null || res2!=null || res3!=null)
                  {
                          model.addAttribute("msg1","User with this Mail-ID or PhoneNumber already exists.Try another Mail-ID and Phone Number");
                          return new ModelAndView("register");
                  }
                  else
                  {
                       final String uri = baseUrl+"/submit_register";                         
                  //    User newUser = new UserPojo(userName,userMail,phone,password,confirmPassword);                    
                      User result = restTemplate.postForObject( uri, user, User.class);
                      return new ModelAndView("login");
                  }
                        
           }
    }


