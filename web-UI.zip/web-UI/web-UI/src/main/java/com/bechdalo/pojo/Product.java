package com.bechdalo.pojo;



import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="product")
public class Product {

	@Id
	String id;
	String productCategory;
	String productPrice;
	String productName;
	String productDescription;
	/*String image1;
	String image2;
	String image3;
	String image4;*/
	String userName;
	String phone;
	String userAddress;
	
	
	Product(){
		
	}
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	
	public String getproductPrice() {
		return productPrice;
	}
	public void setproductPrice(String productPrice) {
		this.productPrice = productPrice;
	}
	public String getphone() {
		return phone;
	}
	public void setphone(String phone) {
		this.phone = phone;
	}
	public String getUserAddress() {
		return userAddress;
	}
	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}
	
	/*public String getimage1() {
		return image1;
	}
	public void setimage1(String image1) {
		this.image1 = image1;
	}
	public String getimage2() {
		return image2;
	}
	public void setimage2(String image2) {
		this.image2 = image2;
	}
	public String getimage3() {
		return image3;
	}
	public void setimage3(String image3) {
		this.image3 = image3;
	}
	public String getimage4() {
		return image4;
	}
	public void setimage4(String image4) {
		this.image4 = image4;
	}*/
	public Product(String userName, String productName, String productDescription, String productCategory,
			String productSubcategory, String productPrice, String phone, String userAddress) {
		super();
		
		this.userName = userName;
		this.productName = productName;
		this.productDescription = productDescription;
		this.productCategory = productCategory;
		//this.productSubcategory = productSubcategory;
		this.productPrice = productPrice;
		this.phone = phone;
		this.userAddress = userAddress;
		/*this.image1 = image1;
		this.image2 = image2;
		this.image3 = image3;
		this.image4 = image4;*/
	}
	
	
}
