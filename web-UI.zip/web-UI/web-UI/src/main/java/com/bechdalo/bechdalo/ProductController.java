package com.bechdalo.bechdalo;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
/*import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;*/
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.bechdalo.pojo.Product;
//import com.capgemini.bechdalo.main.pojo.Product;
@RestController
public class ProductController {
    /*@Autowired
    private DiscoveryClient discoveryClient;

    @RequestMapping("/submitAd")
    public ModelAndView getView(@Valid @ModelAttribute("submit") Product product)
    {
    	
    	
    		ModelAndView mav= new ModelAndView("home");
    	
    	System.out.println("inside");
    List<ServiceInstance> instances=discoveryClient.getInstances("Products");
    ServiceInstance serviceInstance=(ServiceInstance) instances.get(0);
    String baseUrl=serviceInstance.getUri().toString()+"/submitProd";
    
        System.out.println(baseUrl);
      System.out.println(product);
    
      RestTemplate restTemplate=new RestTemplate();
    
    restTemplate.postForObject( baseUrl, product, Product.class);
    return mav;
 }*/

}

