package com.capgemini.bechdalo.group7;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


@RestController
public class UserController {

	
	@Autowired
	private UserService service;
	
	@RequestMapping("/register")
	public ModelAndView openregistration() {
		ModelAndView mav = new ModelAndView("register");
		return mav;
	}
	
	@RequestMapping("/login")
	public ModelAndView openlogin() {
		ModelAndView mav = new ModelAndView("login");
		return mav;
	}
	
	@RequestMapping("/logout")
	public ModelAndView openlogout() {
		ModelAndView mav = new ModelAndView("logout");
		return mav;
	}
	
	
	@RequestMapping(value="/submit_register", method = RequestMethod.POST)
	public User Register(@RequestBody User user ) {
		System.out.println("inside");
		System.out.println(user.getFullname());
		return service.create(user);
	}
	
	@RequestMapping(value = "/email/{email}", method = RequestMethod.GET)
    public User getEmailId(@PathVariable String email)
    {
       return service.findByEmail(email);
    }
    
    
    @RequestMapping(value = "/phone/{phone}", method = RequestMethod.GET)
    public User getPhone(@PathVariable String phone)
    {
       return service.findByPhone(phone);
    }
    
    @RequestMapping(value = "/username/{username}", method = RequestMethod.GET)
    public User getUsername(@PathVariable String username)
    {
       return service.findByUsername(username);
    }

	
	
	@RequestMapping(value="/submit_login", method = RequestMethod.POST)
	public ModelAndView Login(Model model, @ModelAttribute("user1") User user, HttpServletRequest req) {
		if((service.Username(user.getUsername()) != null) && (service.findByPassword(user.getPassword()) != null) ) {
			ModelAndView mav = new ModelAndView(); 
//            HttpSession session=req.getSession();
//            String uname1=uname;
//            session.setAttribute("name", uname1);
//            System.out.println(session.getAttribute("name"));
			//mav.addObject("users", uname);
			mav.setViewName("home");
			return mav;
		}
		else {
			System.out.println("vvv");
			ModelAndView mav = new ModelAndView(); 
			model.addAttribute("msg", "Username or password is incorrect");
			mav.setViewName("login");
			return mav;
		}
		
	}
	
	@PutMapping("/ChangeAddress")
	public User AddressChange(Model model, @RequestBody User user, HttpServletRequest req) {
      System.out.println("hello");
		
      if(service.Username(user.getUsername())!=null) {
		System.out.println(user.getUsername());
		
		System.out.println(ObjectId.get());
    	 return service.create(user);
      }else {
    	  System.out.println("nooooo");
    	  return service.create(user);
      }    	 
	}
}
